export const dynamic = 'force-dynamic'

export default function OrderLookupLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}