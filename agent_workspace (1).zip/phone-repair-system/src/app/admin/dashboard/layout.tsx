export const dynamic = 'force-dynamic'

export default function AdminDashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}