export const dynamic = 'force-dynamic'

export default function TechnicianDashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}